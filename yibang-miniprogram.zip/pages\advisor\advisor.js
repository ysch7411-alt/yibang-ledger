// pages/advisor/advisor.js
const app = getApp();

Page({
  data: {
    topCustomers: []
  },

  onLoad() {
    this.loadData();
  },

  onShow() {
    this.loadData();
  },

  async loadData() {
    try {
      const res = await app.request('/contact/list?type=1');
      if (res.code === 0) {
        // 取前5个欠款最多的
        const sorted = res.data
          .filter(item => item.balance > 0)
          .sort((a, b) => b.balance - a.balance)
          .slice(0, 5);

        const maxBalance = sorted.length > 0 ? sorted[0].balance : 1;
        const customers = sorted.map(item => ({
          ...item,
          percent: (item.balance / maxBalance * 100).toFixed(0)
        }));

        this.setData({ topCustomers: customers });
      }
    } catch (err) {
      console.error('加载数据失败:', err);
    }
  }
});

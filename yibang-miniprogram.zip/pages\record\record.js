// pages/record/record.js
const app = getApp();

Page({
  data: {
    receivable: '0.00',
    payable: '0.00',
    recentList: [],
    showAiModal: false,
    aiResult: {},
    showDailySummary: false,
    dailySummary: {}
  },

  onLoad() {
    this.loadData();
  },

  onShow() {
    this.loadData();
  },

  // 加载数据
  async loadData() {
    try {
      // 加载往来汇总
      const summaryRes = await app.request('/contact/summary');
      if (summaryRes.code === 0) {
        this.setData({
          receivable: summaryRes.data.receivable.toFixed(2),
          payable: summaryRes.data.payable.toFixed(2)
        });
      }

      // 加载最近记录
      const recordRes = await app.request('/record/list?page=1&size=10');
      if (recordRes.code === 0) {
        this.setData({
          recentList: recordRes.data
        });
      }
    } catch (err) {
      console.error('加载数据失败:', err);
    }
  },

  // 点击加号
  onPlusTap() {
    wx.showActionSheet({
      itemList: ['拍照', '相册', '传文件'],
      success: (res) => {
        if (res.tapIndex === 0) {
          this.takePhoto();
        } else if (res.tapIndex === 1) {
          this.chooseImage();
        } else {
          this.chooseFile();
        }
      }
    });
  },

  // 拍照
  takePhoto() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['camera'],
      success: (res) => {
        this.uploadImage(res.tempFiles[0].tempFilePath);
      }
    });
  },

  // 相册
  chooseImage() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album'],
      success: (res) => {
        this.uploadImage(res.tempFiles[0].tempFilePath);
      }
    });
  },

  // 传文件
  chooseFile() {
    wx.chooseMessageFile({
      count: 1,
      type: 'file',
      success: (res) => {
        wx.showToast({ title: '文件上传功能开发中', icon: 'none' });
      }
    });
  },

  // 上传图片并AI识别
  async uploadImage(filePath) {
    wx.showLoading({ title: '识别中...' });
    try {
      // 先上传文件
      const uploadRes = await new Promise((resolve, reject) => {
        wx.uploadFile({
          url: app.globalData.apiBase + '/file/upload',
          filePath: filePath,
          name: 'file',
          header: {
            'Authorization': 'Bearer ' + app.globalData.token
          },
          success: resolve,
          fail: reject
        });
      });

      const result = JSON.parse(uploadRes.data);
      if (result.code === 0) {
        // TODO: 调用OCR识别
        wx.showToast({ title: '图片识别功能开发中', icon: 'none' });
      }
    } catch (err) {
      wx.showToast({ title: '上传失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  },

  // 点击输入框
  onInputTap() {
    wx.showModal({
      title: '记一笔',
      editable: true,
      placeholderText: '比如：今天收了张老板5000块货款',
      success: (res) => {
        if (res.confirm && res.content) {
          this.aiParse(res.content);
        }
      }
    });
  },

  // 点击麦克风
  onMicTap() {
    wx.showToast({ title: '语音识别功能开发中', icon: 'none' });
  },

  // AI解析
  async aiParse(text) {
    wx.showLoading({ title: 'AI识别中...' });
    try {
      const res = await app.request('/record/ai-parse', {
        method: 'POST',
        data: { text }
      });

      wx.hideLoading();
      if (res.code === 0) {
        this.setData({
          showAiModal: true,
          aiResult: res.data
        });
      }
    } catch (err) {
      wx.hideLoading();
      wx.showToast({ title: '识别失败', icon: 'none' });
    }
  },

  // 关闭AI弹窗
  closeAiModal() {
    this.setData({ showAiModal: false });
  },

  // 确认记账
  async confirmRecord() {
    const { aiResult } = this.data;
    wx.showLoading({ title: '保存中...' });

    try {
      const res = await app.request('/record/create', {
        method: 'POST',
        data: {
          type: this.typeToCode(aiResult.type),
          amount: aiResult.amount,
          content: aiResult.content,
          record_date: new Date().toISOString().split('T')[0]
        }
      });

      wx.hideLoading();
      if (res.code === 0) {
        this.setData({ showAiModal: false });
        wx.showToast({ title: '记账成功', icon: 'success' });
        this.loadData();
        this.showDailySummaryModal();
      }
    } catch (err) {
      wx.hideLoading();
      wx.showToast({ title: '保存失败', icon: 'none' });
    }
  },

  // 类型转代码
  typeToCode(type) {
    const map = { '收入': 1, '支出': 2, '应收': 3, '应付': 4, '回款': 5, '付款': 6 };
    return map[type] || 2;
  },

  // 显示每日汇总
  async showDailySummaryModal() {
    const date = new Date().toISOString().split('T')[0];
    try {
      const res = await app.request('/record/daily-summary?date=' + date);
      if (res.code === 0) {
        this.setData({
          showDailySummary: true,
          dailySummary: res.data
        });
      }
    } catch (err) {
      console.error('获取汇总失败:', err);
    }
  },

  // 关闭每日汇总
  closeDailySummary() {
    this.setData({ showDailySummary: false });
  },

  // 分享汇总
  shareSummary() {
    wx.showToast({ title: '分享功能开发中', icon: 'none' });
  }
});

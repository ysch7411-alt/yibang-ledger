// pages/summary/summary.js
const app = getApp();

Page({
  data: {
    receivable: '0.00',
    payable: '0.00',
    activeTab: 'receivable',
    contactList: []
  },

  onLoad() {
    this.loadData();
  },

  onShow() {
    this.loadData();
  },

  async loadData() {
    try {
      // 加载汇总
      const summaryRes = await app.request('/contact/summary');
      if (summaryRes.code === 0) {
        this.setData({
          receivable: summaryRes.data.receivable.toFixed(2),
          payable: summaryRes.data.payable.toFixed(2)
        });
      }

      // 加载往来列表
      await this.loadContactList();
    } catch (err) {
      console.error('加载数据失败:', err);
    }
  },

  async loadContactList() {
    const type = this.data.activeTab === 'receivable' ? 1 : 2;
    try {
      const res = await app.request('/contact/list?type=' + type);
      if (res.code === 0) {
        this.setData({ contactList: res.data });
      }
    } catch (err) {
      console.error('加载往来列表失败:', err);
    }
  },

  switchTab(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({ activeTab: tab });
    this.loadContactList();
  }
});

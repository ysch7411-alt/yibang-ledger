// pages/search/search.js
const app = getApp();

Page({
  data: {
    keyword: '',
    recordList: []
  },

  onLoad() {
    this.loadRecords();
  },

  onShow() {
    this.loadRecords();
  },

  async loadRecords() {
    try {
      const res = await app.request('/record/list?page=1&size=50');
      if (res.code === 0) {
        this.setData({ recordList: res.data });
      }
    } catch (err) {
      console.error('加载记录失败:', err);
    }
  },

  onSearchInput(e) {
    this.setData({ keyword: e.detail.value });
  },

  onSearch() {
    // TODO: 实现搜索过滤
    wx.showToast({ title: '搜索功能开发中', icon: 'none' });
  },

  onAiChat() {
    wx.showToast({ title: 'AI问答功能开发中', icon: 'none' });
  }
});

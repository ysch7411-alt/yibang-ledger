// app.js
App({
  globalData: {
    userInfo: null,
    token: '',
    apiBase: 'https://api.dtzai.cn/api'
  },

  onLaunch() {
    // 检查本地token
    const token = wx.getStorageSync('token');
    if (token) {
      this.globalData.token = token;
    }
    // 静默登录
    this.login();
  },

  // 微信登录
  login() {
    return new Promise((resolve, reject) => {
      wx.login({
        success: async (res) => {
          if (res.code) {
            try {
              const result = await this.request('/user/login', {
                method: 'POST',
                data: { code: res.code }
              });
              if (result.code === 0) {
                this.globalData.token = result.data.token;
                this.globalData.userInfo = result.data.user;
                wx.setStorageSync('token', result.data.token);
                wx.setStorageSync('userInfo', result.data.user);
                resolve(result.data);
              } else {
                reject(result);
              }
            } catch (err) {
              reject(err);
            }
          }
        }
      });
    });
  },

  // 封装请求
  request(url, options = {}) {
    return new Promise((resolve, reject) => {
      wx.request({
        url: this.globalData.apiBase + url,
        method: options.method || 'GET',
        data: options.data || {},
        header: {
          'Authorization': 'Bearer ' + this.globalData.token,
          'Content-Type': 'application/json'
        },
        success: (res) => {
          if (res.statusCode === 401) {
            // token过期，重新登录
            this.login().then(() => {
              this.request(url, options).then(resolve).catch(reject);
            });
            return;
          }
          resolve(res.data);
        },
        fail: (err) => {
          console.error('请求失败:', err);
          wx.showToast({
            title: '网络错误',
            icon: 'none'
          });
          reject(err);
        }
      });
    });
  }
});

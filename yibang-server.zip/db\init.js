const pool = require('./config');

async function initTables() {
  const sqlList = [
    `CREATE TABLE IF NOT EXISTS users (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      openid VARCHAR(64) UNIQUE NOT NULL,
      nickname VARCHAR(100),
      shop_name VARCHAR(100),
      role TINYINT DEFAULT 1 COMMENT '1老板 2店员',
      boss_id BIGINT NULL,
      plan_type TINYINT DEFAULT 0,
      storage_used BIGINT DEFAULT 0,
      storage_limit BIGINT DEFAULT 5368709120,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS contacts (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      user_id BIGINT NOT NULL,
      name VARCHAR(100) NOT NULL,
      type TINYINT COMMENT '1客户 2供应商 3两者',
      phone VARCHAR(20),
      remark TEXT,
      balance DECIMAL(12,2) DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS transactions (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      user_id BIGINT NOT NULL,
      contact_id BIGINT NULL,
      type TINYINT COMMENT '1收入 2支出 3应收 4应付 5回款 6付款',
      amount DECIMAL(12,2),
      content VARCHAR(255),
      record_date DATE,
      status TINYINT DEFAULT 1 COMMENT '0待审核 1已入账 2驳回',
      created_by BIGINT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS files (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      user_id BIGINT NOT NULL,
      transaction_id BIGINT NULL,
      file_url VARCHAR(500),
      file_type VARCHAR(20),
      file_size BIGINT,
      ocr_result TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`,

    `CREATE TABLE IF NOT EXISTS shares (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      token VARCHAR(64) UNIQUE NOT NULL,
      user_id BIGINT NOT NULL,
      type TINYINT COMMENT '1每日汇总 2客户对账',
      contact_id BIGINT NULL,
      data_date DATE NULL,
      expire_at DATETIME,
      is_valid TINYINT DEFAULT 1,
      view_count INT DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`
  ];

  for (const sql of sqlList) {
    await pool.query(sql);
  }

  console.log('✅ 数据表初始化完成');
  process.exit(0);
}

initTables().catch(err => {
  console.error('❌ 初始化失败:', err);
  process.exit(1);
});

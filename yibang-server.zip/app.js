require('dotenv').config();
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// 创建上传目录
if (!fs.existsSync(process.env.UPLOAD_DIR)) {
  fs.mkdirSync(process.env.UPLOAD_DIR, { recursive: true });
}

// 中间件
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 健康检测接口
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    message: '易帮账本后端服务运行中',
    time: new Date().toISOString()
  });
});

// 路由模块
app.use('/api/user', require('./routes/user'));
app.use('/api/record', require('./routes/record'));
app.use('/api/contact', require('./routes/contact'));
app.use('/api/share', require('./routes/share'));
app.use('/api/file', require('./routes/file'));
app.use('/api/staff', require('./routes/staff'));

// 错误处理中间件
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ code: 500, msg: '服务器内部错误' });
});

app.listen(PORT, () => {
  console.log(`易帮账本后端服务启动成功，端口: ${PORT}`);
});

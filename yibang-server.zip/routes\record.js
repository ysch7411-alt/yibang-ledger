const express = require('express');
const router = express.Router();
const pool = require('../db/config');
const jwt = require('jsonwebtoken');
const axios = require('axios');

// 中间件：验证token
function auth(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) {
    return res.json({ code: 401, msg: '未登录' });
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.userId;
    next();
  } catch (err) {
    return res.json({ code: 401, msg: 'token无效' });
  }
}

// AI识别记账
router.post('/ai-parse', auth, async (req, res) => {
  const { text } = req.body;
  if (!text) {
    return res.json({ code: 400, msg: '缺少文本内容' });
  }

  try {
    // 调用阿里云百炼大模型解析
    const aiRes = await axios.post(
      process.env.DASHSCOPE_BASE_URL + '/chat/completions',
      {
        model: 'qwen-plus',
        messages: [
          {
            role: 'system',
            content: '你是一个记账助手，从用户输入中提取：金额、交易类型(收入/支出/应收/应付/回款/付款)、往来对象、事由。返回JSON格式：{amount:数字, type:"收入/支出/应收/应付/回款/付款", contact:"往来对象", content:"事由"}'
          },
          { role: 'user', content: text }
        ],
        temperature: 0.1
      },
      {
        headers: {
          'Authorization': 'Bearer ' + process.env.DASHSCOPE_API_KEY,
          'Content-Type': 'application/json'
        }
      }
    );

    const aiText = aiRes.data.choices[0].message.content;
    let parsed;
    try {
      parsed = JSON.parse(aiText.replace(/```json|```/g, '').trim());
    } catch (e) {
      parsed = { amount: 0, type: '支出', contact: '', content: text };
    }

    res.json({ code: 0, data: parsed });
  } catch (err) {
    console.error('AI解析错误:', err.message);
    res.json({ code: 500, msg: 'AI解析失败', data: { amount: 0, type: '支出', contact: '', content: text } });
  }
});

// 创建记账记录
router.post('/create', auth, async (req, res) => {
  const { contact_id, type, amount, content, record_date } = req.body;

  try {
    const [result] = await pool.query(
      'INSERT INTO transactions (user_id, contact_id, type, amount, content, record_date, status, created_by) VALUES (?, ?, ?, ?, ?, ?, 1, ?)',
      [req.userId, contact_id, type, amount, content, record_date, req.userId]
    );

    res.json({ code: 0, msg: '记账成功', data: { id: result.insertId } });
  } catch (err) {
    console.error('记账错误:', err);
    res.json({ code: 500, msg: '记账失败' });
  }
});

// 获取记录列表
router.get('/list', auth, async (req, res) => {
  const { page = 1, size = 20 } = req.query;
  const offset = (page - 1) * size;

  try {
    const [rows] = await pool.query(
      'SELECT t.*, c.name as contact_name FROM transactions t LEFT JOIN contacts c ON t.contact_id = c.id WHERE t.user_id = ? ORDER BY t.created_at DESC LIMIT ? OFFSET ?',
      [req.userId, parseInt(size), parseInt(offset)]
    );

    res.json({ code: 0, data: rows });
  } catch (err) {
    res.json({ code: 500, msg: '获取记录失败' });
  }
});

// 每日汇总
router.get('/daily-summary', auth, async (req, res) => {
  const { date } = req.query;

  try {
    const [income] = await pool.query(
      "SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE user_id = ? AND type IN (1,5) AND record_date = ? AND status = 1",
      [req.userId, date]
    );

    const [expense] = await pool.query(
      "SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE user_id = ? AND type IN (2,6) AND record_date = ? AND status = 1",
      [req.userId, date]
    );

    const [details] = await pool.query(
      'SELECT t.*, c.name as contact_name FROM transactions t LEFT JOIN contacts c ON t.contact_id = c.id WHERE t.user_id = ? AND t.record_date = ? AND t.status = 1 ORDER BY t.created_at DESC',
      [req.userId, date]
    );

    res.json({
      code: 0,
      data: {
        income: income[0].total,
        expense: expense[0].total,
        net: income[0].total - expense[0].total,
        details
      }
    });
  } catch (err) {
    res.json({ code: 500, msg: '获取汇总失败' });
  }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const pool = require('../db/config');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

function auth(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.json({ code: 401, msg: '未登录' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.userId;
    next();
  } catch (err) {
    return res.json({ code: 401, msg: 'token无效' });
  }
}

// 配置multer文件上传
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, process.env.UPLOAD_DIR);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + '-' + Math.random().toString(36).substring(7) + ext);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB
});

// 文件上传
router.post('/upload', auth, upload.single('file'), async (req, res) => {
  if (!req.file) {
    return res.json({ code: 400, msg: '请选择文件' });
  }

  try {
    const fileUrl = `/uploads/${req.file.filename}`;
    const [result] = await pool.query(
      'INSERT INTO files (user_id, file_url, file_type, file_size) VALUES (?, ?, ?, ?)',
      [req.userId, fileUrl, req.file.mimetype, req.file.size]
    );

    res.json({
      code: 0,
      msg: '上传成功',
      data: {
        id: result.insertId,
        url: fileUrl,
        size: req.file.size
      }
    });
  } catch (err) {
    res.json({ code: 500, msg: '上传失败' });
  }
});

// 文件列表
router.get('/list', auth, async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT * FROM files WHERE user_id = ? ORDER BY created_at DESC LIMIT 50',
      [req.userId]
    );
    res.json({ code: 0, data: rows });
  } catch (err) {
    res.json({ code: 500, msg: '获取文件列表失败' });
  }
});

module.exports = router;

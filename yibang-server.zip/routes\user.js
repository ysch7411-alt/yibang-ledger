const express = require('express');
const router = express.Router();
const pool = require('../db/config');
const jwt = require('jsonwebtoken');
const axios = require('axios');

// 微信登录
router.post('/login', async (req, res) => {
  const { code } = req.body;
  if (!code) {
    return res.json({ code: 400, msg: '缺少code参数' });
  }

  try {
    // 调用微信接口获取openid
    const wxUrl = `https://api.weixin.qq.com/sns/jscode2session?appid=${process.env.WX_APPID}&secret=${process.env.WX_SECRET}&js_code=${code}&grant_type=authorization_code`;
    const wxRes = await axios.get(wxUrl);

    if (wxRes.data.errcode) {
      return res.json({ code: 400, msg: '微信登录失败: ' + wxRes.data.errmsg });
    }

    const openid = wxRes.data.openid;

    // 查询或创建用户
    const [rows] = await pool.query('SELECT * FROM users WHERE openid = ?', [openid]);

    let user;
    if (rows.length === 0) {
      // 新用户
      const [result] = await pool.query(
        'INSERT INTO users (openid, role) VALUES (?, 1)',
        [openid]
      );
      user = {
        id: result.insertId,
        openid,
        role: 1,
        plan_type: 0
      };
    } else {
      user = rows[0];
    }

    // 生成JWT token
    const token = jwt.sign(
      { userId: user.id, openid: user.openid },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.json({
      code: 0,
      msg: '登录成功',
      data: {
        token,
        user: {
          id: user.id,
          nickname: user.nickname,
          shop_name: user.shop_name,
          role: user.role,
          plan_type: user.plan_type
        }
      }
    });
  } catch (err) {
    console.error('登录错误:', err);
    res.json({ code: 500, msg: '登录失败' });
  }
});

// 获取用户信息
router.get('/info', async (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) {
    return res.json({ code: 401, msg: '未登录' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const [rows] = await pool.query('SELECT id, nickname, shop_name, role, plan_type FROM users WHERE id = ?', [decoded.userId]);

    if (rows.length === 0) {
      return res.json({ code: 404, msg: '用户不存在' });
    }

    res.json({ code: 0, data: rows[0] });
  } catch (err) {
    res.json({ code: 401, msg: 'token无效' });
  }
});

module.exports = router;
